# Tipos de dados

* Gramática

    > Elementos da linguagem e suas combinações
    > A arte de falar e escrever corretamente

* Vocabulário

    > Conjunto de termos e expressões
    > Agrupamento de palavras

* Preciamos saber como escrever
* Precisamos saber os significados
* Preciamos continuar aprendendo para crescer nosso vocabulário

# Como vai ser a dinâmica do aprendizado?

* Conceitos e escrita

    > Vamos aprender os tipos de dados mais utilizados na linguagem

        - Você sabia que é possível aprender 80% de uma língua nova com cerca de 28% do vocabulário? (até menos)


----------

# Diferença entre null e undefined

* undefined

    > Algo que não vai existir

* null

    > Nulo
    > Objeto que não possui nada dentro
    > Diferente de indefinido

----------

# Objeto # 

* Objeto

    > Funcionalidades / Atributos
    > Funcionalidades / Métodos

----------

HTML

Para dar início ao HTML -> ! + Enter

Para quebrar linhas -> <br>

Para usar negrito -> <strong></strong> ou <b></b>

Para usar itálico -> <em></em> ou <i></i>

Para criar espaços -> &nbsp;

Para criar "maior que" -> &gt;

Para criar "menor que" -> &lt;

Para usar aspas duplas -> &quot;

Para usar aspas simples -> &apos;

Para usar & ou E comercial -> &amp;

----------

