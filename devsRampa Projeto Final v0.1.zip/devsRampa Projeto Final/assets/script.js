/*
function atualizarLista(){
    var listaDeProdutos = new Array();
    listaDeProdutos[0] = prompt("Digite um produto:");
    if(listaDeProdutos[listaDeProdutos.length]===null){
        listaDeProdutos.pop(listaDeProdutos.length);
    }
    var adicionarProduto = parseInt(prompt("Deseja adicionar mais um produto?"));
    if (adicionarProduto === 1) {
        while (adicionarProduto === 1){
        listaDeProdutos[listaDeProdutos.length] = prompt("Digite mais um produto:");
        console.log(listaDeProdutos);
        adicionarProduto = prompt("Continuar? OBS: Deixe em branco para cancelar");
            if (adicionarProduto === null) {
                adicionarProduto = 2;
            } else {
                adicionarProduto = 1;
            }
        }
    }
}

function botaoCalculoIMC(){
    const alturaIMC = document.getElementById("entradaAlturaIMC").value;
    console.log(alturaIMC);
    const pesoIMC = document.getElementById("entradaPesoIMC").value;
    console.log(pesoIMC);
    const resultadoIMC = pesoIMC/(alturaIMC*alturaIMC);
    alert(resultadoIMC);
    console.log(resultadoIMC);
    return resultadoIMC;

/*
    if (imc > 18.5){
        alert("Você está abaixo do peso (Grau 0). Seu IMC é: " + imc);
    }
    else if (imc >= 18.5 <= 24.9){
        alert("Você está no peso ideal (Grau 0). Seu IMC é: " + imc);
    }
    else if (imc >= 25 <= 29.9){
        alert("Você está acima do peso (Grau I). Seu IMC é: " + imc);
        }
    else if (imc >= 30 <= 39.9){
        alert("Você está com obesidade (Grau II). Seu IMC é: " + imc);
    }
    else {
        alert("Você está com obesidade grave (Grau III). Seu IMC é: ");
    }
}
*/

function exibirCalcIMC(){
    document.querySelector("#iframeCalcIMC").style.display = "block";
}

function calcularIMC(){
    let alturaIMC = document.querySelector("#entradaAlturaIMC").value;
    alturaIMC = parseFloat(alturaIMC);
    if(alturaIMC > 100){
        alturaIMC = alturaIMC/10;
    }
    let pesoIMC = document.querySelector("#entradaPesoIMC").value;
    pesoIMC = parseFloat(pesoIMC);
    var resultadoIMC = querySelector("#exibirSaidaCalcIMC");
    if(resultadoIMC === null){
        resultadoIMC = pesoIMC/(alturaIMC*alturaIMC);
        alert(resultadoIMC);
        resultadoIMC.value;
    }
}